import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:ffmpeg_kit_flutter_new/ffmpeg_kit.dart';
import 'package:ffmpeg_kit_flutter_new/ffmpeg_kit_config.dart';
import 'package:ffmpeg_kit_flutter_new/ffprobe_kit.dart';
import 'package:ffmpeg_kit_flutter_new/return_code.dart';
import 'package:flutter/material.dart';
import 'package:gal/gal.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:video_player/video_player.dart';
import 'package:webview_flutter/webview_flutter.dart';

// ---------------------------------------------------------------------------
// Video Compressor by Anas — on-device compression, Monetag web ads only.
// NO AdMob / google_mobile_ads anywhere in this app (proven startup crash).
// ---------------------------------------------------------------------------

const String kMonetagDirectLink = 'https://uplcm.com/4/12269238';
const String kVersionJsonUrl =
    'https://raw.githubusercontent.com/anashaider904-blip/video-compressor/main/version.json';

void main() {
  runApp(const VideoCompressorApp());
}

class VideoCompressorApp extends StatelessWidget {
  const VideoCompressorApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Video Compressor',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue.shade800),
        useMaterial3: true,
      ),
      home: const StartupGate(),
    );
  }
}

// ---------------------------------------------------------------------------
// Force update gate
// ---------------------------------------------------------------------------

class UpdateInfo {
  final int latestVersionCode;
  final String latestVersionName;
  final String apkUrl;
  final String message;
  UpdateInfo(this.latestVersionCode, this.latestVersionName, this.apkUrl,
      this.message);
}

Future<UpdateInfo?> checkForUpdate() async {
  try {
    final info = await PackageInfo.fromPlatform();
    final currentCode = int.tryParse(info.buildNumber) ?? 0;
    final resp =
        await http.get(Uri.parse(kVersionJsonUrl)).timeout(const Duration(seconds: 6));
    if (resp.statusCode != 200) return null;
    final data = jsonDecode(resp.body) as Map<String, dynamic>;
    final latest = (data['latestVersionCode'] as num?)?.toInt() ?? 0;
    if (latest > currentCode) {
      return UpdateInfo(
        latest,
        (data['latestVersionName'] ?? '').toString(),
        (data['apkUrl'] ?? '').toString(),
        (data['message'] ?? 'A new version is available.').toString(),
      );
    }
  } catch (_) {
    // Offline or file missing -> app runs normally, never lock the user out.
  }
  return null;
}

class StartupGate extends StatefulWidget {
  const StartupGate({super.key});

  @override
  State<StartupGate> createState() => _StartupGateState();
}

class _StartupGateState extends State<StartupGate> {
  UpdateInfo? _update;
  bool _checked = false;

  @override
  void initState() {
    super.initState();
    _run();
  }

  Future<void> _run() async {
    final u = await checkForUpdate();
    if (!mounted) return;
    setState(() {
      _update = u;
      _checked = true;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (!_checked) {
      return const Scaffold(
        body: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.compress, size: 72, color: Colors.blue),
              SizedBox(height: 16),
              Text('Video Compressor',
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
              SizedBox(height: 16),
              CircularProgressIndicator(),
            ],
          ),
        ),
      );
    }
    if (_update != null) return ForceUpdateScreen(update: _update!);
    return const HomeScreen();
  }
}

class ForceUpdateScreen extends StatelessWidget {
  final UpdateInfo update;
  const ForceUpdateScreen({super.key, required this.update});

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      child: Scaffold(
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.system_update, size: 84, color: Colors.blue),
                const SizedBox(height: 20),
                const Text('New Update Available',
                    style:
                        TextStyle(fontSize: 26, fontWeight: FontWeight.bold),
                    textAlign: TextAlign.center),
                const SizedBox(height: 12),
                if (update.latestVersionName.isNotEmpty)
                  Text('Version ${update.latestVersionName} is ready',
                      style: const TextStyle(fontSize: 16)),
                const SizedBox(height: 12),
                Text(update.message,
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 15, color: Colors.black54)),
                const SizedBox(height: 12),
                const Text(
                    'Please update to keep using Video Compressor.',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 15)),
                const SizedBox(height: 28),
                SizedBox(
                  width: double.infinity,
                  height: 56,
                  child: ElevatedButton.icon(
                    icon: const Icon(Icons.download),
                    label: const Text('Update Now',
                        style: TextStyle(fontSize: 18)),
                    onPressed: () async {
                      final url = update.apkUrl.trim();
                      if (url.isEmpty) return;
                      await Navigator.of(context).push(MaterialPageRoute(
                        builder: (_) => _DownloadScreen(url: url),
                      ));
                    },
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _DownloadScreen extends StatefulWidget {
  final String url;
  const _DownloadScreen({required this.url});

  @override
  State<_DownloadScreen> createState() => _DownloadScreenState();
}

class _DownloadScreenState extends State<_DownloadScreen> {
  late final WebViewController _controller;

  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..loadRequest(Uri.parse(widget.url));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Download Update')),
      body: WebViewWidget(controller: _controller),
    );
  }
}

// ---------------------------------------------------------------------------
// Monetag ad screen (proven GrabAll route — WebView Direct Link, no SDK)
// ---------------------------------------------------------------------------

class AdScreen extends StatefulWidget {
  const AdScreen({super.key});

  @override
  State<AdScreen> createState() => _AdScreenState();
}

class _AdScreenState extends State<AdScreen> {
  WebViewController? _controller;
  int _secondsLeft = 5;
  bool _canClose = false;
  Timer? _closeTimer;
  Timer? _autoTimer;
  bool _closed = false;

  @override
  void initState() {
    super.initState();
    try {
      _controller = WebViewController()
        ..setJavaScriptMode(JavaScriptMode.unrestricted)
        ..setNavigationDelegate(NavigationDelegate(
          onWebResourceError: (_) {},
        ))
        ..loadRequest(Uri.parse(kMonetagDirectLink));
    } catch (_) {
      _controller = null;
    }
    _closeTimer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) return;
      setState(() {
        _secondsLeft--;
        if (_secondsLeft <= 0) {
          _canClose = true;
          t.cancel();
        }
      });
    });
    _autoTimer = Timer(const Duration(seconds: 30), _close);
  }

  void _close() {
    if (_closed || !mounted) return;
    _closed = true;
    Navigator.of(context).pop();
  }

  @override
  void dispose() {
    _closeTimer?.cancel();
    _autoTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: _canClose,
      child: Scaffold(
        appBar: AppBar(
          automaticallyImplyLeading: false,
          title: const Text('Advertisement'),
          actions: [
            TextButton(
              onPressed: _canClose ? _close : null,
              child: Text(
                _canClose ? 'Close ✕' : 'Close in $_secondsLeft…',
                style: TextStyle(
                    color: _canClose ? Colors.blue : Colors.grey,
                    fontWeight: FontWeight.bold),
              ),
            ),
          ],
        ),
        body: _controller == null
            ? const Center(child: Text('Ad unavailable'))
            : WebViewWidget(controller: _controller!),
      ),
    );
  }
}

Future<void> showAd(BuildContext context) async {
  try {
    await Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => const AdScreen(), fullscreenDialog: true),
    );
  } catch (_) {
    // An ad must NEVER block the main function.
  }
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

String formatSize(int bytes) {
  if (bytes < 1024) return '$bytes B';
  if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(1)} KB';
  if (bytes < 1024 * 1024 * 1024) {
    return '${(bytes / (1024 * 1024)).toStringAsFixed(2)} MB';
  }
  return '${(bytes / (1024 * 1024 * 1024)).toStringAsFixed(2)} GB';
}

String formatDuration(double seconds) {
  final d = Duration(seconds: seconds.round());
  final m = d.inMinutes;
  final s = d.inSeconds % 60;
  if (m >= 60) {
    return '${d.inHours}h ${m % 60}m ${s}s';
  }
  return '${m}m ${s.toString().padLeft(2, '0')}s';
}

Future<Directory> myVideosDir() async {
  final docs = await getApplicationDocumentsDirectory();
  final dir = Directory(p.join(docs.path, 'videos'));
  if (!await dir.exists()) await dir.create(recursive: true);
  return dir;
}

// ---------------------------------------------------------------------------
// Home / compress
// ---------------------------------------------------------------------------

class VideoInfoData {
  final File file;
  final int sizeBytes;
  final double durationSec;
  final int width;
  final int height;
  VideoInfoData(this.file, this.sizeBytes, this.durationSec, this.width,
      this.height);
}

enum Preset { whatsapp, p720, p480, p360, custom }

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  VideoInfoData? _video;
  Preset _preset = Preset.whatsapp;
  double _customCrf = 28;
  bool _picking = false;
  bool _compressing = false;
  double _progress = 0;
  int? _sessionId;
  String _statusText = '';

  Future<void> _pickVideo() async {
    setState(() => _picking = true);
    try {
      final picker = ImagePicker();
      final picked = await picker.pickVideo(source: ImageSource.gallery);
      if (picked == null) return;
      final file = File(picked.path);
      final size = await file.length();
      double duration = 0;
      int w = 0, h = 0;
      try {
        final session = await FFprobeKit.getMediaInformation(picked.path);
        final media = session.getMediaInformation();
        if (media != null) {
          duration = double.tryParse(media.getDuration() ?? '0') ?? 0;
          for (final stream in media.getStreams()) {
            final sw = stream.getWidth() ?? 0;
            final sh = stream.getHeight() ?? 0;
            if (sw > 0 && sh > 0) {
              w = sw;
              h = sh;
              break;
            }
          }
        }
      } catch (_) {}
      if (!mounted) return;
      setState(() {
        _video = VideoInfoData(file, size, duration, w, h);
      });
    } finally {
      if (mounted) setState(() => _picking = false);
    }
  }

  String _buildCommand(String input, String output) {
    final v = _video!;
    String scaleFilter;
    String codecArgs;
    switch (_preset) {
      case Preset.whatsapp:
        // Target ~15.5 MB total so it always fits WhatsApp's 16 MB limit.
        const targetBytes = 15.5 * 1024 * 1024;
        final dur = v.durationSec > 0 ? v.durationSec : 60.0;
        var videoBitrate = ((targetBytes * 8) / dur) - 64000;
        if (videoBitrate > 2500000) videoBitrate = 2500000;
        if (videoBitrate < 200000) videoBitrate = 200000;
        final vb = videoBitrate.round();
        scaleFilter = "scale=-2:'min(720,ih)'";
        codecArgs =
            '-c:v libx264 -preset veryfast -b:v $vb -maxrate $vb -bufsize ${vb * 2} -c:a aac -b:a 64k';
        break;
      case Preset.p720:
        scaleFilter = "scale=-2:'min(720,ih)'";
        codecArgs = '-c:v libx264 -preset veryfast -crf 26 -c:a aac -b:a 96k';
        break;
      case Preset.p480:
        scaleFilter = "scale=-2:'min(480,ih)'";
        codecArgs = '-c:v libx264 -preset veryfast -crf 28 -c:a aac -b:a 80k';
        break;
      case Preset.p360:
        scaleFilter = "scale=-2:'min(360,ih)'";
        codecArgs = '-c:v libx264 -preset veryfast -crf 30 -c:a aac -b:a 64k';
        break;
      case Preset.custom:
        scaleFilter = "scale=-2:ih";
        codecArgs =
            '-c:v libx264 -preset veryfast -crf ${_customCrf.round()} -c:a aac -b:a 96k';
        break;
    }
    return '-y -i "$input" -vf "$scaleFilter" $codecArgs -movflags +faststart "$output"';
  }

  Future<void> _startCompress() async {
    final v = _video;
    if (v == null || _compressing) return;

    await showAd(context); // ad #1 — before compression starts
    if (!mounted) return;

    final dir = await myVideosDir();
    final stamp = DateTime.now().millisecondsSinceEpoch;
    final outFile = File(p.join(dir.path, 'compressed_$stamp.mp4'));
    final command = _buildCommand(v.file.path, outFile.path);

    setState(() {
      _compressing = true;
      _progress = 0;
      _statusText = 'Compressing…';
    });

    try {
      await FFmpegKit.executeAsync(
        command,
        (session) async {
          final rc = await session.getReturnCode();
          if (!mounted) return;
          if (ReturnCode.isSuccess(rc)) {
            await _onCompressDone(v, outFile);
          } else if (ReturnCode.isCancel(rc)) {
            setState(() {
              _compressing = false;
              _statusText = 'Cancelled';
            });
            try {
              if (await outFile.exists()) await outFile.delete();
            } catch (_) {}
          } else {
            setState(() {
              _compressing = false;
              _statusText = 'Compression failed. Please try another preset.';
            });
          }
        },
        null,
        (statistics) {
          if (!mounted || v.durationSec <= 0) return;
          final timeMs = statistics.getTime();
          setState(() {
            _progress = (timeMs / (v.durationSec * 1000)).clamp(0.0, 1.0);
          });
        },
      ).then((session) {
        _sessionId = session.getSessionId();
      });
    } catch (_) {
      if (mounted) {
        setState(() {
          _compressing = false;
          _statusText = 'Compression failed to start.';
        });
      }
    }
  }

  Future<void> _onCompressDone(VideoInfoData original, File outFile) async {
    // Save a copy to the phone Gallery, album "VideoCompressor" (MediaStore).
    bool savedToGallery = false;
    try {
      final hasAccess = await Gal.hasAccess();
      if (!hasAccess) await Gal.requestAccess();
      await Gal.putVideo(outFile.path, album: 'VideoCompressor');
      savedToGallery = true;
    } catch (_) {
      savedToGallery = false;
    }

    final newSize = await outFile.length();
    if (!mounted) return;
    setState(() => _compressing = false);

    await showAd(context); // ad #2 — after compression completes
    if (!mounted) return;

    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => ResultScreen(
        outputFile: outFile,
        originalSize: original.sizeBytes,
        newSize: newSize,
        savedToGallery: savedToGallery,
      ),
    ));
  }

  Future<void> _cancelCompress() async {
    final id = _sessionId;
    if (id != null) {
      try {
        await FFmpegKit.cancel(id);
      } catch (_) {}
    }
  }

  Widget _presetTile(Preset value, String title, String subtitle) {
    return Card(
      color: _preset == value
          ? Theme.of(context).colorScheme.primaryContainer
          : null,
      child: RadioListTile<Preset>(
        value: value,
        groupValue: _preset,
        onChanged: _compressing
            ? null
            : (v) => setState(() => _preset = v ?? _preset),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(subtitle),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final v = _video;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Video Compressor'),
        actions: [
          IconButton(
            icon: const Icon(Icons.video_library),
            tooltip: 'My Videos',
            onPressed: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const MyVideosScreen()),
            ),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            SizedBox(
              height: 64,
              child: ElevatedButton.icon(
                icon: const Icon(Icons.video_file, size: 28),
                label: Text(
                    _picking ? 'Opening…' : 'Choose Video from Gallery',
                    style: const TextStyle(fontSize: 18)),
                onPressed: _compressing || _picking ? null : _pickVideo,
              ),
            ),
            const SizedBox(height: 16),
            if (v != null)
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(p.basename(v.file.path),
                          style: const TextStyle(
                              fontWeight: FontWeight.bold, fontSize: 15),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis),
                      const SizedBox(height: 8),
                      Text('Size: ${formatSize(v.sizeBytes)}'),
                      if (v.durationSec > 0)
                        Text('Duration: ${formatDuration(v.durationSec)}'),
                      if (v.width > 0 && v.height > 0)
                        Text('Resolution: ${v.width} × ${v.height}'),
                    ],
                  ),
                ),
              ),
            if (v != null) ...[
              const SizedBox(height: 8),
              const Text('Choose quality:',
                  style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              _presetTile(Preset.whatsapp, 'WhatsApp',
                  'Smallest — fits WhatsApp (under 16 MB), best for sharing'),
              _presetTile(Preset.p720, '720p HD',
                  'Good quality, much smaller size'),
              _presetTile(Preset.p480, '480p', 'Balanced size and quality'),
              _presetTile(Preset.p360, '360p', 'Very small, fast to send'),
              _presetTile(Preset.custom, 'Custom',
                  'Use the slider to pick your own quality'),
              if (_preset == Preset.custom)
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 8),
                  child: Column(
                    children: [
                      Slider(
                        value: _customCrf,
                        min: 18,
                        max: 40,
                        divisions: 22,
                        label: 'Quality ${_customCrf.round()}',
                        onChanged: _compressing
                            ? null
                            : (val) => setState(() => _customCrf = val),
                      ),
                      const Text(
                          'Lower number = better quality, bigger file. Higher = smaller file.',
                          style: TextStyle(color: Colors.black54)),
                    ],
                  ),
                ),
              const SizedBox(height: 16),
              if (_compressing) ...[
                LinearProgressIndicator(value: _progress),
                const SizedBox(height: 8),
                Text(
                    'Compressing… ${(_progress * 100).toStringAsFixed(0)}%',
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 16)),
                const SizedBox(height: 10),
                OutlinedButton.icon(
                  icon: const Icon(Icons.cancel),
                  label: const Text('Cancel'),
                  onPressed: _cancelCompress,
                ),
              ] else
                SizedBox(
                  height: 60,
                  child: FilledButton.icon(
                    icon: const Icon(Icons.compress, size: 26),
                    label: const Text('Compress Video',
                        style: TextStyle(fontSize: 19)),
                    onPressed: _startCompress,
                  ),
                ),
              if (_statusText.isNotEmpty && !_compressing) ...[
                const SizedBox(height: 10),
                Text(_statusText,
                    textAlign: TextAlign.center,
                    style: const TextStyle(color: Colors.red)),
              ],
            ],
            const SizedBox(height: 20),
            const Text(
              'Compression happens 100% on your phone. Nothing is uploaded anywhere.',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.black45),
            ),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Result
// ---------------------------------------------------------------------------

class ResultScreen extends StatelessWidget {
  final File outputFile;
  final int originalSize;
  final int newSize;
  final bool savedToGallery;

  const ResultScreen({
    super.key,
    required this.outputFile,
    required this.originalSize,
    required this.newSize,
    required this.savedToGallery,
  });

  @override
  Widget build(BuildContext context) {
    final savedPct = originalSize > 0
        ? ((1 - newSize / originalSize) * 100).clamp(0, 100)
        : 0.0;
    return Scaffold(
      appBar: AppBar(title: const Text('Done!')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Icon(Icons.check_circle, size: 80, color: Colors.green),
            const SizedBox(height: 16),
            const Text('Video Compressed!',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
            const SizedBox(height: 24),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    _row('Before', formatSize(originalSize)),
                    _row('After', formatSize(newSize)),
                    const Divider(),
                    _row('You saved', '${savedPct.toStringAsFixed(1)}%',
                        bold: true),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),
            Text(
              savedToGallery
                  ? 'Saved to your Gallery in the "VideoCompressor" album.'
                  : 'Saved in My Videos inside the app.',
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.black54),
            ),
            const SizedBox(height: 24),
            SizedBox(
              height: 56,
              child: FilledButton.icon(
                icon: const Icon(Icons.play_arrow),
                label: const Text('Play Video', style: TextStyle(fontSize: 17)),
                onPressed: () => Navigator.of(context).push(MaterialPageRoute(
                  builder: (_) => VideoPlayScreen(file: outputFile),
                )),
              ),
            ),
            const SizedBox(height: 10),
            SizedBox(
              height: 56,
              child: OutlinedButton.icon(
                icon: const Icon(Icons.share),
                label: const Text('Share', style: TextStyle(fontSize: 17)),
                onPressed: () =>
                    Share.shareXFiles([XFile(outputFile.path)]),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _row(String label, String value, {bool bold = false}) {
    final style = TextStyle(
        fontSize: 17, fontWeight: bold ? FontWeight.bold : FontWeight.normal);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [Text(label, style: style), Text(value, style: style)],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// My Videos
// ---------------------------------------------------------------------------

class MyVideosScreen extends StatefulWidget {
  const MyVideosScreen({super.key});

  @override
  State<MyVideosScreen> createState() => _MyVideosScreenState();
}

class _MyVideosScreenState extends State<MyVideosScreen> {
  List<File> _files = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final dir = await myVideosDir();
    final entries = dir
        .listSync()
        .whereType<File>()
        .where((f) => f.path.toLowerCase().endsWith('.mp4'))
        .toList()
      ..sort((a, b) => b.path.compareTo(a.path));
    if (!mounted) return;
    setState(() {
      _files = entries;
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('My Videos')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _files.isEmpty
              ? const Center(
                  child: Text('No compressed videos yet.',
                      style: TextStyle(fontSize: 16)))
              : ListView.builder(
                  itemCount: _files.length,
                  itemBuilder: (context, i) {
                    final f = _files[i];
                    final size = f.lengthSync();
                    return Card(
                      margin: const EdgeInsets.symmetric(
                          horizontal: 12, vertical: 6),
                      child: ListTile(
                        leading: const Icon(Icons.movie, size: 36),
                        title: Text(p.basename(f.path),
                            maxLines: 1, overflow: TextOverflow.ellipsis),
                        subtitle: Text(formatSize(size)),
                        onTap: () => Navigator.of(context).push(
                          MaterialPageRoute(
                              builder: (_) => VideoPlayScreen(file: f)),
                        ),
                        trailing: PopupMenuButton<String>(
                          onSelected: (action) async {
                            if (action == 'share') {
                              await Share.shareXFiles([XFile(f.path)]);
                            } else if (action == 'delete') {
                              try {
                                await f.delete();
                              } catch (_) {}
                              _load();
                            }
                          },
                          itemBuilder: (_) => const [
                            PopupMenuItem(
                                value: 'share', child: Text('Share')),
                            PopupMenuItem(
                                value: 'delete', child: Text('Delete')),
                          ],
                        ),
                      ),
                    );
                  },
                ),
    );
  }
}

// ---------------------------------------------------------------------------
// Player
// ---------------------------------------------------------------------------

class VideoPlayScreen extends StatefulWidget {
  final File file;
  const VideoPlayScreen({super.key, required this.file});

  @override
  State<VideoPlayScreen> createState() => _VideoPlayScreenState();
}

class _VideoPlayScreenState extends State<VideoPlayScreen> {
  late final VideoPlayerController _controller;
  bool _ready = false;

  @override
  void initState() {
    super.initState();
    _controller = VideoPlayerController.file(widget.file);
    _controller.initialize().then((_) {
      if (!mounted) return;
      setState(() => _ready = true);
      _controller.play();
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(p.basename(widget.file.path))),
      body: Center(
        child: _ready
            ? AspectRatio(
                aspectRatio: _controller.value.aspectRatio == 0
                    ? 16 / 9
                    : _controller.value.aspectRatio,
                child: VideoPlayer(_controller),
              )
            : const CircularProgressIndicator(),
      ),
      floatingActionButton: _ready
          ? FloatingActionButton(
              onPressed: () {
                setState(() {
                  _controller.value.isPlaying
                      ? _controller.pause()
                      : _controller.play();
                });
              },
              child: Icon(_controller.value.isPlaying
                  ? Icons.pause
                  : Icons.play_arrow),
            )
          : null,
    );
  }
}
